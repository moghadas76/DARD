module.exports = {
    HOST : 'localhost',
    USER : 'root',
    PASSWORD : 'm13761376',
    DATABASE : 'size'
}