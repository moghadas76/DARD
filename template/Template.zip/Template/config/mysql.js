module.exports = {
    HOST : '192.168.1.54',
    USER : 'pfd',
    PASSWORD : 'pfd',
    DATABASE : 'PFD',
    TABLE : 'SIPCallsEvent'
}
