var express = require('express');
var mysql = require('mysql');
var db = require('../config/mysql');


var router = express.Router();

  // var connection = mysql.createConnection({
  //   host     : db.HOST,
  //   user     : db.USER,
  //   password : db.PASSWORD,
  //   database : db.DATABASE
  // });


  // connection.connect();
  
router.get('/', function(req, res, next) {
	res.render('login');
});

router.post('/', function(req, res, next) {
 	var user = req.body.user_name;
 	var pass = req.body.password;
	if (user==="admin" && pass==="admin"){
		res.redirect('/index');	
	}

});


router.post('/filter', function(req, res, next) {
	pageNum = 1;
	PER_PAGE = 10;
	skip = PER_PAGE*pageNum - PER_PAGE;
	console.log(req.body.start_date,req.body.start_time,req.body.stop_date,req.body.stop_time); 	
	var start_date = req.body.start_date + " " + req.body.start_time;
	var stop_date = req.body.stop_date + " " + req.body.stop_time;
	var from = req.body.from;
	var to = req.body.to;
	var impi = req.body.impi;
	var event_type = req.body.event_type;
	var form_data = {start_date: req.body.start_date, start_time: req.body.start_time, stop_date : req.body.stop_date, stop_time:req.body.stop_time, from : from, to : to,impi : impi}
	var query = "SELECT * FROM "+db.TABLE+" WHERE 1=1 AND StartTime between '"+start_date+"' AND '"+stop_date+"' ";
	if (from){
		query += "AND "+db.TABLE+".From LIKE '%"+from+"%' ";	
	}
	if (to){
		query += "AND "+db.TABLE+".To LIKE '%"+to+"%' ";	
	}
	if (impi){
		query += "AND "+db.TABLE+".IMPI LIKE '%"+impi+"%' ";	
	}
	
	var EOQ = " ORDER BY StartTime DESC LIMIT "+PER_PAGE+" OFFSET "+skip +";";
	var AOQ = " ORDER BY StartTime DESC ;";
	var agr = query + AOQ;
	query += EOQ;
 	console.log(query);
	var aggregate_query = agr.replace("*","count(*)");

	var connection = mysql.createConnection({
	    host     : db.HOST,
	    user     : db.USER,
	    password : db.PASSWORD,
	    database : db.DATABASE,
		dateStrings : true
	  });
	  connection.connect();
	  connection.query(query, function (error, results, fields) {
	    if (error) throw error;
		var records;
		connection.query(aggregate_query,function(error,rows,fields){
			console.log(rows);
			records = rows[0]['count(*)'];
			console.log(records);				
			res.json({ title: 'Express',item : results,pages:Math.ceil(records/PER_PAGE),current:pageNum});	
		});
	  });
	

});


router.get('/search', function(req, res, next) {
	pageNum = req.query.page;
	PER_PAGE = 10;
	skip = PER_PAGE*pageNum - PER_PAGE; 	
	var start_date = req.query.start_date + " " + req.query.start_time;
	var stop_date = req.query.stop_date + " " + req.query.stop_time;
	var from = req.query.from;
	var to = req.query.to;
	var impi = req.query.impi;
	var event_type = req.query.event_type;
	var form_data = {start_date: req.query.start_date, start_time: req.query.start_time, stop_date : req.query.stop_date, stop_time:req.query.stop_time, from : from, to : to,impi : impi}
	var query = "SELECT * FROM "+db.TABLE+" WHERE 1=1 AND StartTime between '"+start_date+"' AND '"+stop_date+"' ";
	if (from){
		query += "AND "+db.TABLE+".From LIKE '%"+from+"%' ";	
	}
	if (to){
		query += "AND "+db.TABLE+".To LIKE '%"+to+"%' ";	
	}
	if (impi){
		query += "AND "+db.TABLE+".IMPI LIKE '%"+impi+"%' ";	
	}
	
	var EOQ = " ORDER BY StartTime DESC LIMIT "+PER_PAGE+" OFFSET "+skip +";";
	var AOQ = " ORDER BY StartTime DESC ;";
	var agr = query + AOQ;
	query += EOQ;
 	console.log(query);
	var aggregate_query = agr.replace("*","count(*)");


	var connection = mysql.createConnection({
	    host     : db.HOST,
	    user     : db.USER,
	    password : db.PASSWORD,
	    database : db.DATABASE,
		dateStrings : true
	  });
	  connection.connect();
	  connection.query(query, function (error, results, fields) {
	    if (error) throw error;
		var records;
		connection.query(aggregate_query,function(error,rows,fields){
			console.log(rows);
			records = rows[0]['count(*)'];
			console.log(records);				
			res.json({ title: 'Express',item : results,pages:Math.ceil(records/PER_PAGE),current:pageNum});	
		});
	  });
});


/* GET home page. */
router.get('/index', function(req, res, next) {
	/*pageNum = req.params.page;
	PER_PAGE = 5;
	skip = PER_PAGE*pageNum - PER_PAGE;
	var connection = mysql.createConnection({
    host     : db.HOST,
    user     : db.USER,
    password : db.PASSWORD,
    database : db.DATABASE,
	dateStrings : true
  });


  connection.connect();

  connection.query('SELECT * from ' + db.TABLE + ' LIMIT '+PER_PAGE+' OFFSET '+skip, function (error, results, fields) {
    if (error) throw error;
	var records;
	connection.query('SELECT count(*) FROM '+db.TABLE,function(error,rows,fields){
		console.log(rows);
		records = rows[0]['count(*)'];
		console.log(records);				
		res.render('index', { title: 'Express',item : results});	
	});
    
  });
 */
	var form = {start_date:'' , stop_date:'' , from:'' , to:'',impi:''}
	res.render('index',{item:null,form:form});
  
});

router.post('/',function(req, res, next) {
  var connection = mysql.createConnection({
    host     : db.HOST,
    user     : db.USER,
    password : db.PASSWORD,
    database : db.DATABASE
  });

  connection.connect();
  
  console.log(req.body.name);
for(var i=0;i<10000;i++)
	  connection.query("INSERT INTO `person` (`name`, `length`) VALUES ('"+i+"','"+i+"');", function (error, results) {
	    if (error) throw error;
	    console.log("ok:)");
	  });
	    res.redirect('/1');
 connection.end();


});
  
 
module.exports = router;

